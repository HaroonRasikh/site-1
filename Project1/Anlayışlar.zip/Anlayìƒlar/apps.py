from django.apps import AppConfig


class AnlayışlarConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Anlayışlar'
