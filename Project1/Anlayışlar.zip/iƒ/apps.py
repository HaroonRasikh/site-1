from django.apps import AppConfig


class IşConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'iş'
    verbose_name = 'işlar'
